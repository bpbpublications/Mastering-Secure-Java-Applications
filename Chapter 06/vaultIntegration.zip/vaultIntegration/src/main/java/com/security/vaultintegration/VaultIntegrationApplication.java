package com.security.vaultintegration;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.vault.core.VaultKeyValueOperationsSupport.KeyValueBackend;
import org.springframework.vault.core.VaultTemplate;
import org.springframework.vault.support.VaultResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.log4j.Log4j2;

@SpringBootApplication
@RestController
@Log4j2
@RequestMapping("/api")
public class VaultIntegrationApplication {
    @Autowired
    private VaultTemplate vaultTemplate;

    public void run(String... strings) throws Exception {
        VaultResponse response = vaultTemplate
                .opsForKeyValue("secret", KeyValueBackend.KV_2).get("testapp/database");
        log.info("Value of github.oauth2.key {}",response.getData().get("spring.database.username"));
        response.getData().get("spring.database.url");
    }

    @GetMapping("/")
    public String home() {
        VaultResponse response = vaultTemplate
                .opsForKeyValue("secret", KeyValueBackend.KV_2).get("testapp/database");
        log.info("Value of Username {}",response.getData().get("spring.database.username"));
        log.info("Value of Password {}",response.getData().get("spring.database.password"));
        log.info("Value of URL {}",response.getData().get("spring.database.url"));
        return "Hello World!";
    }

    public static void main(String[] args) {
        SpringApplication.run(VaultIntegrationApplication.class, args);
    }
}

